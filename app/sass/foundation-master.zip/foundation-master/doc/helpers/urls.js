// module.exports.js_path = function () { 
//   return assets;  
// };

// module.exports.img_path = function () { 
//   return assets;
// };

// module.exports.css_path = function () { 
//   return assets;
// };